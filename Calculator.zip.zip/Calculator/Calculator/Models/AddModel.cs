﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Collections.ObjectModel;

namespace Calculator.Models
{
    public class AddModel
    {
        public double Number1 { get; set; }

        public double Number2 { get; set; }

        public double Result { get; set; }

    }
}



